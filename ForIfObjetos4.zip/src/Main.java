import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int contadorAte100 = 0;
        int contadorAte200 = 0;
        int contadorAcima200 = 0;

        for (int i = 0; i < 20; i++) {
            System.out.print("Digite um número: ");
            int numero = scanner.nextInt();

            if (numero >= 0 && numero <= 100) {
                contadorAte100++;
            } else if (numero >= 101 && numero <= 200) {
                contadorAte200++;
            } else {
                contadorAcima200++;
            }
        }

        System.out.println("Quantidade de números entre 0 e 100: " + contadorAte100);
        System.out.println("Quantidade de números entre 101 e 200: " + contadorAte200);
        System.out.println("Quantidade de números maiores que 200: " + contadorAcima200);

        scanner.close();
    }
}
