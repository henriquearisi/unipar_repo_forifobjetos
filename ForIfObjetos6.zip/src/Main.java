public class Main {
    public static void main(String[] args) {
        // Criando uma instância de ContaBancaria
        ContaBancaria conta = new ContaBancaria("123456");

        // Realizando operações na conta
        conta.depositar(1000);
        conta.sacar(500);

        // Consultando o saldo atual da conta
        double saldoAtual = conta.consultarSaldo();
        System.out.println("Saldo atual da conta: " + saldoAtual);
    }
}
