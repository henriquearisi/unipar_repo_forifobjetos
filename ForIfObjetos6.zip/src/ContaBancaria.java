public class ContaBancaria {
    private double saldo;
    private String numeroConta;

    // Construtor sem parâmetros
    public ContaBancaria() {
        this.numeroConta = ""; // Inicializa o número da conta como vazio
        this.saldo = 0.0; // Inicializa o saldo como zero
    }

    // Construtor com parâmetro para o número da conta
    public ContaBancaria(String numeroConta) {
        this.numeroConta = numeroConta;
        this.saldo = 0.0; // Inicializa o saldo como zero
    }

    // Método para depositar um valor na conta
    public void depositar(double valor) {
        saldo += valor;
    }

    // Método para sacar um valor da conta
    public void sacar(double valor) {
        if (valor <= saldo) {
            saldo -= valor;
        } else {
            System.out.println("Saldo insuficiente para realizar o saque.");
        }
    }

    // Método para consultar o saldo atual da conta
    public double consultarSaldo() {
        return saldo;
    }
}
