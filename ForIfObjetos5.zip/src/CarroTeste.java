public class CarroTeste {
    public static void main(String[] args) {
        Carro carro1 = new Carro("Toyota", "Corolla", 180);
        Carro carro2 = new Carro("Volkswagen", "Golf", 200);

        System.out.println("Carro 1 - Marca: " + carro1.getMarca() + ", Modelo: " + carro1.getModelo() +
                ", Velocidade Máxima: " + carro1.getVelocidadeMaxima() + " km/h");
        System.out.println("Carro 2 - Marca: " + carro2.getMarca() + ", Modelo: " + carro2.getModelo() +
                ", Velocidade Máxima: " + carro2.getVelocidadeMaxima() + " km/h");
    }
}
